from checker import *

class ExtendedChecker(Checker):

	def __init__(self):
		Checker.__init__(self, 'e')

