from checker import *

class SmallChecker(Checker):

	def __init__(self):
		Checker.__init__(self, 's')

