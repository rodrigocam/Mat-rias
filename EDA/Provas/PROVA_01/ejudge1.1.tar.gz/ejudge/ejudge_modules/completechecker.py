from checker import *

class CompleteChecker(Checker):

	def __init__(self):
		Checker.__init__(self, 'c')

